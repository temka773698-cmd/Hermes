<?php
return [
    'site_name' => 'АкваСтрой',
    'telegram_bot_token' => '',
    'telegram_group_chat_id' => '',
    'timezone' => 'Europe/Moscow',
];
